#include <iostream>

using namespace std;

int main()
{
    cout << "First 10 natural numbers using for loop: " << endl;

    for (int i = 1; i <= 10; i++) {
        cout << i << " ";
    }

    return 0;
}
