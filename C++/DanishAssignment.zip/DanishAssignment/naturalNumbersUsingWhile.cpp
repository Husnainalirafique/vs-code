#include <iostream>

using namespace std;

int main()
{
    int i = 1;

    cout << "First 10 natural numbers using while loop: " << endl;

    while (i <= 10) {
        cout << i << " ";
        i++;
    }

    return 0;
}
